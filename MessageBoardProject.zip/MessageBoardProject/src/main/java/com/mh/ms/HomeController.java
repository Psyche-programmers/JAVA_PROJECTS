package com.mh.ms;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	//here HomeController class is a controller class which impleminted with controller class
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		//for formated date which have to be shown as server time.
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		String formattedDate = dateFormat.format(date);
		model.addAttribute("serverTime", formattedDate );
		
		//return page is home.jsp
		return "home";
	}
	
	   @RequestMapping(value = "hello", method = RequestMethod.POST)
	   public String addName(@ModelAttribute("SpringWeb")MB name, 
	   ModelMap model,Locale locale) {
		   
		   //for getting the formated date
		   Date date = new Date();
		   DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		   String formattedDate = dateFormat.format(date);
		   model.addAttribute("serverTime", "welcome "+formattedDate);
		   
		   //for getting the greeting names from bean file
	       model.addAttribute("name", "hi..!"+name.getName());
	      //return page is success.jsp
	      return "home";
	   }
	
}
