package com.mh.ms;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MB {
	
	//bean class for getter and setter of properties
	private static Logger log = LoggerFactory.getLogger(MB.class);
	  private String name,date;

	  public String getName() {
	  	return name;
	  }

	  public void setName(String name) {
	  	this.name = name;
	  }

	  public String getDate() {
	  	return date;
	  }

	  public void setDate(String date) {
	  	this.date = date;
	  }
}
